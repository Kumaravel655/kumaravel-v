from django.contrib import admin
from .models import Employ,EmployAdmin


# Register your models here.

admin.site.register(Employ,EmployAdmin)
