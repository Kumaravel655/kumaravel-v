from django.db import models
from django.contrib import admin

# Create your models here.
class Employ(models.Model):
    empno = models.IntegerField()
    name = models.CharField(max_length=100)
    salary = models.IntegerField()
    phone = models.IntegerField()
    email = models.CharField(max_length=30)
    address =models.CharField(max_length=200)

class EmployAdmin(admin.ModelAdmin):
    list_display = ('empno','name','salary','phone','email','address') 
    