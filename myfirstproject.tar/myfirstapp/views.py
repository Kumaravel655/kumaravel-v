from django.shortcuts import render

# Create your views here.
def myfirstdynamicpage(request):
    context = {}
    return render(request,'myfirstapp/firstdynamicfile.html',context),
def mymarksheetpage(request):
    context = {}
    return render(request,'myfirstapp/marksheet.html',context)
def topthreelaptoppage(request):
    context = {}
    return render(request,'myfirstapp/topthreelaptop.html',context)
def layout1(request):
    context = {}
    return render(request,'myfirstapp/layout1.html',context)
def layout2(request):
    context = {}
    return render(request,'myfirstapp/layout2.html',context)
def layout3(request):
    context = {}
    return render(request,'myfirstapp/layout3.html',context)
def layout4(request):
    context = {}
    return render(request,'myfirstapp/layout4.html',context)
def scientist(request):
    context = {}
    return render(request,'myfirstapp/scientist.html',context)

